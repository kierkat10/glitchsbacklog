# Glitch's Backlog
## Overview
A collection of currently Pending suggestions by Glitchkat10 for the popular Cryptid mod, as they are too damn slow.
Requires Cryptid.
## Additions
### Jokers
- Buddy Jolly
- Brick by Brick
- Hotdog
- Hotdog Stand
- Pixar Lamp
- Chakra
- Electric Joker
- Inequality Alligator
### Decks
- Weezer Deck
## To-Do List
- Just keep adding more stuff (next planned things to add are probably Dad Joke, Inequality Alligator, and Opposite Day)
