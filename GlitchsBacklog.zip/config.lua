return {
	["buddyjollysfx"] = true,
}